from django.db import models

# models
def cont_struct():
  pass
