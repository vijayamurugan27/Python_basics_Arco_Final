<h4 align = 'center'> content aggregator </h4>
<hr>
<h4> filters </h4>
<code>geo location</code>
<code>content type</code>
<code>data category</code>
<code>time</code>
<code>area</code>

<h4> set filters: edit <code>configs</code> file </h4>
<br>

```python3
python3 -m c_a
```
